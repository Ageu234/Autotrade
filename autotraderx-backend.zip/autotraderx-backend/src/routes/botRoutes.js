const express = require('express');
const connectToDeriv = require('../services/derivClient');
const router = express.Router();

router.post('/start', (req, res) => {
  const { token } = req.body;
  const ws = connectToDeriv(token);

  res.json({ message: 'Bot iniciado. Conectando com a Deriv...' });
});

module.exports = router;
