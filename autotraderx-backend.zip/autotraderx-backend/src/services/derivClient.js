const WebSocket = require('ws');

function connectToDeriv(token) {
  const ws = new WebSocket('wss://ws.deriv.com/websockets/v3?app_id=1089');

  ws.on('open', () => {
    ws.send(JSON.stringify({
      authorize: token,
    }));
  });

  ws.on('message', (data) => {
    const response = JSON.parse(data);
    console.log('[DERIV]', response);
  });

  ws.on('error', (err) => {
    console.error('[WS ERROR]', err);
  });

  return ws;
}

module.exports = connectToDeriv;
